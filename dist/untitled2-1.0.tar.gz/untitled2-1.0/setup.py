# setup.py
from distutils.core import setup

setup(name='untitled2',
      version='1.0',
      author='Ormaniec',
      author_email='226181@student.pwr.edu.pl',
      url='https://github.com/TheMesoria/untitled2',
      packages=['untitled2', 'untitled2.utils'],
      )
