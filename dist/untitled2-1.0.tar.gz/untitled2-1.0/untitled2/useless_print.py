
def useless_print():
    print(" WOAH ")