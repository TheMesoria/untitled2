
def ormaniec_add(val):
    assert isinstance(val, int)
    return 20 + val;