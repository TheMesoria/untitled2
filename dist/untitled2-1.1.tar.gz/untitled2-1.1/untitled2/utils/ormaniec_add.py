
def ormaniec_add(val, new_val):
    assert isinstance(val, int)
    return 20 + val + new_val;